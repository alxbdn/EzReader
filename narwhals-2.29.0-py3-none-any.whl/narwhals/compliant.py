"""Public protocols for plugin authors."""

from __future__ import annotations

from narwhals._compliant import (
    CompliantDataFrame,
    CompliantExpr,
    CompliantGroupBy,
    CompliantLazyFrame,
    CompliantNamespace,
    CompliantSeries,
    EagerDataFrame,
    EagerExpr,
    EagerNamespace,
    EagerSeries,
)
from narwhals._compliant.any_namespace import (
    CatNamespace,
    DateTimeNamespace,
    ListNamespace,
    MapNamespace,
    StringNamespace,
    StructNamespace,
)
from narwhals._compliant.expr import CompliantExprNameNamespace
from narwhals._compliant.selectors import CompliantSelector, CompliantSelectorNamespace

__all__ = [
    "CatNamespace",
    "CompliantDataFrame",
    "CompliantExpr",
    "CompliantExprNameNamespace",
    "CompliantGroupBy",
    "CompliantLazyFrame",
    "CompliantNamespace",
    "CompliantSelector",
    "CompliantSelectorNamespace",
    "CompliantSeries",
    "DateTimeNamespace",
    "EagerDataFrame",
    "EagerExpr",
    "EagerNamespace",
    "EagerSeries",
    "ListNamespace",
    "MapNamespace",
    "StringNamespace",
    "StructNamespace",
]
